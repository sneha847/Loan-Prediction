from flask import Flask, render_template, request
import pandas as pd
import pickle
from sklearn.decomposition import PCA
import os

app = Flask(__name__)

# Load models
model_path = os.path.join(os.path.dirname(__file__), 'models')
with open(os.path.join(model_path, 'scaler.pkl'), 'rb') as f:
    scaler = pickle.load(f)
with open(os.path.join(model_path, 'kmeans_model.pkl'), 'rb') as f:
    kmeans = pickle.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    # Load and preprocess data
    data_path = os.path.join(os.path.dirname(__file__), 'data.csv')
    data = pd.read_csv(data_path, encoding='ISO-8859-1')
    data.dropna(subset=['CustomerID'], inplace=True)
    data = data[(data['Quantity'] > 0) & (data['UnitPrice'] > 0)]
    data['TotalPrice'] = data['Quantity'] * data['UnitPrice']
    data['InvoiceDate'] = pd.to_datetime(data['InvoiceDate'],format='mixed')
    snapshot_date = data['InvoiceDate'].max() + pd.Timedelta(days=1)

    # Compute RFM
    rfm = data.groupby('CustomerID').agg({
        'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
        'InvoiceNo': 'nunique',
        'TotalPrice': 'sum'
    }).rename(columns={'InvoiceDate': 'Recency', 
                       'InvoiceNo': 'Frequency', 
                       'TotalPrice': 'Monetary'})
    rfm = rfm[rfm['Monetary'] > 0]

    # Normalize and predict clusters
    rfm_normalized = scaler.transform(rfm)
    rfm['Cluster'] = kmeans.predict(rfm_normalized)

    # Optional: PCA for visualization
    pca = PCA(n_components=2)
    rfm_pca = pca.fit_transform(rfm_normalized)
    rfm['PCA1'] = rfm_pca[:, 0]
    rfm['PCA2'] = rfm_pca[:, 1]

    # Convert to HTML table
    result_table = rfm.reset_index().to_html(classes='table table-bordered', index=False)

    return render_template('result.html', tables=[result_table], title='Customer Segmentation')

if __name__ == '__main__':
    app.run(debug=True)